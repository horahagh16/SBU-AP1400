package golestan.exceptions;

public class InvalidCourseNumberException extends  RegistrationException {
    public InvalidCourseNumberException(int num) {
        // TODO
super();
    }
}
