package calendar.exception;

public class IllegalCalendarFormatException extends RuntimeException {
    public IllegalCalendarFormatException() {
        super();
    }
}
